package com.lge.notyet.server.exception;

public class InvalidCardInformationException extends SureParkException {
    public InvalidCardInformationException() {
        super("INVALID_CARD_INFORMATION");
    }
}
