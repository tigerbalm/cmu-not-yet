package com.lge.notyet.server.exception;

public abstract class SureParkException extends Exception {
    public SureParkException(String message) {
        super(message);
    }
}
