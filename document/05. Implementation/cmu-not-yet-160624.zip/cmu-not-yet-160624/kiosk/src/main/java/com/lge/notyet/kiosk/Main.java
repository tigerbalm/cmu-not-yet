package com.lge.notyet.kiosk;

import com.fazecast.jSerialComm.SerialPort;
import com.lge.notyet.kiosk.ui.KioskGUI;

/**
 * Created by sjun.lee on 2016-06-09.
 */
public class Main {
    public static void main(String[] args) {
        KioskGUI.showGui();
    }
}
