// FacilityConfiguration.h

#ifndef _FACILITYCONFIGURATION_h
#define _FACILITYCONFIGURATION_h

#define FACILITY_ID		1
#endif

