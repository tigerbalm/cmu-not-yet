package com.lge.notyet.kiosk.message;

/**
 * Created by sjun.lee on 2016-06-21.
 */
public interface MyMessage {
    byte[] buffer();

    String text();
}
