# Channel Interface Index

## Request-Response Channels

- Sign Up Channel
- Login Channel
- Logout Channel
- Get Reservation Channel
- Get Facilities Channel
- Get Reservable Facilities Channel
- Get Slots Channel
- Make Reservation Channel
- Cancel Reservation Channel
- Confirm Reservation Channel
- Confirm Exit Channel
- Get Statistics Channel
- Update Facility Channel

## Publish-Subscribe Channels

- Controller Status Channel
- Controller Error Report Channel
- Slot Status Channel
- Reservation Status Channel 

