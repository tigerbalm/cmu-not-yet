// stdafx.cpp : source file that includes just the standard includes
// Mosquitto_Auth_Plugin_Dll.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"


