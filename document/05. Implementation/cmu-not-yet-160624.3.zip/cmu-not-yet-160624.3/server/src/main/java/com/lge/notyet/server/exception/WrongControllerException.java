package com.lge.notyet.server.exception;

public class WrongControllerException extends SureParkException {
    public WrongControllerException() {
        super("WRONG_CONTROLLER");
    }
}
