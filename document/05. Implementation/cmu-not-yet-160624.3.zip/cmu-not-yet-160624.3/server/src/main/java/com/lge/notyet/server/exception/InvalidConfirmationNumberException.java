package com.lge.notyet.server.exception;

public class InvalidConfirmationNumberException extends SureParkException {
    public InvalidConfirmationNumberException() {
        super("INVALID_CONFIRMATION_NO");
    }
}
