// CommandRequestPayment.h

#ifndef _COMMANDREQUESTPAYMENT_h
#define _COMMANDREQUESTPAYMENT_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif


#endif

