// SlotConfiguration.h

#ifndef _SLOTCONFIGURATION_h
#define _SLOTCONFIGURATION_h

#define MAX_SLOT_COUNT	4

#define SLOT_PIN_1		30
#define SLOT_PIN_2		31
#define SLOT_PIN_3		32
#define SLOT_PIN_4		33
#endif