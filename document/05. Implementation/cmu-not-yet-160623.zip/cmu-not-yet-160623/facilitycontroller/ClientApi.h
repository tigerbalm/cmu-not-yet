// ClientApi.h

#ifndef _CLIENTAPI_h
#define _CLIENTAPI_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif

class ClientApi {
public:

};
#endif

