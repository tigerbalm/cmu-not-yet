package com.lge.notyet.server.security;

public enum Privilege {
    READ_FACILITY,
    WRITE_FACILITY,
    READ_RESERVATION,
    WRITE_RESERVATION,
    READ_STATISTICS
}